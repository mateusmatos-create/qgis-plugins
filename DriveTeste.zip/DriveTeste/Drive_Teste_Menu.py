from qgis.PyQt.QtWidgets import QAction, QMenu
from qgis.core import QgsApplication
from qgis.PyQt.QtGui import QIcon
from qgis import processing
import os

# --- Importa a classe do seu PRIMEIRO script de processamento -   --
from .DT_UE_Measurement import DT_UE_Measurement

# --- Importar a classe do seu SEGUNDO script ---
from .DT_Number_Elements import DT_Number_Elements

# --- Adicionar a importação para o seu script de GRÁFICO ---
from .Grafico_QDialog import abrir_janela_grafico 

class DriveTesteMenu:
    """Classe principal do Plugin."""

    def __init__(self, iface): 
        """Construtor."""
        self.iface = iface
        self.plugin_menu = None 
        self.actions = []
        self.menu_title = "&Drive Teste" 
        self.plugin_dir = os.path.dirname(__file__)
        
    def initGui(self):
        """Cria os elementos da interface gráfica (menu e botões)."""
        
        menu_bar = self.iface.mainWindow().menuBar()
        self.plugin_menu = QMenu(self.menu_title, self.iface.mainWindow())
        menu_bar.addMenu(self.plugin_menu)

        # --- Ação para o PRIMEIRO script ---
        alg_um = DT_UE_Measurement()
        icon_um = alg_um.icon()
        self.action_script_um = QAction(
            icon_um,
            "DT_UE_Measurement",
            self.iface.mainWindow()
        )
        self.action_script_um.triggered.connect(self.run_script_um)
        self.plugin_menu.addAction(self.action_script_um)
        self.actions.append(self.action_script_um)

        # --- Ação para o SEGUNDO script ---
        alg_dois = DT_Number_Elements()
        icon_dois = alg_dois.icon() 
        self.action_script_dois = QAction(
            icon_dois,
            "DT_Number_Elements",
            self.iface.mainWindow()
        )
        self.action_script_dois.triggered.connect(self.run_script_dois)
        self.plugin_menu.addAction(self.action_script_dois)
        self.actions.append(self.action_script_dois)

        # --- Ação para o script do GRÁFICO COM ÍCONE ---
        # Cria o caminho completo para o ícone
        icon_path = os.path.join(self.plugin_dir, 'icon_grafico.svg')
        # Cria o objeto QIcon
        icon_grafico = QIcon(icon_path)
        
        self.action_grafico = QAction(
            icon_grafico,
            "Análise Gráfica",
            self.iface.mainWindow()
        )
        self.action_grafico.triggered.connect(self.run_grafico)
        self.plugin_menu.addAction(self.action_grafico)
        self.actions.append(self.action_grafico)


    def unload(self):
        """Remove os elementos da interface gráfica quando o plugin é desativado."""
        if self.plugin_menu:
            menu_bar = self.iface.mainWindow().menuBar()
            menu_bar.removeAction(self.plugin_menu.menuAction())
        
        self.actions.clear()
        self.plugin_menu = None

    def run_script_um(self):
        """Abre a janela de diálogo do PRIMEIRO algoritmo."""
        provider = DT_UE_Measurement()
        processing.execAlgorithmDialog(provider)

    def run_script_dois(self):
        """Abre a janela de diálogo do SEGUNDO algoritmo."""
        provider = DT_Number_Elements()
        processing.execAlgorithmDialog(provider)

    # --- Nova função para executar o script do GRÁFICO ---
    def run_grafico(self):
        """Chama a função que abre a janela de diálogo do gráfico."""
        abrir_janela_grafico()