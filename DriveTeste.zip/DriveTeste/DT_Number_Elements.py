from qgis.PyQt.QtCore import QCoreApplication
import pandas as pd
import os
from qgis import processing
from urllib.parse import quote
from PyQt5.QtCore import QVariant
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterNumber,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsVectorLayer,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsFeatureSink,
    QgsProcessingException,
    QgsWkbTypes,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject
)

class DT_Number_Elements(QgsProcessingAlgorithm):
    """
    Este script agrega dados de um CSV, gera pontos em uma linha (rua),
    cria um buffer ao redor desses pontos, associa atributos dos dados
    agregados e, finalmente, agrega os resultados por ponto da rua.
    """
    INPUT_CSV = 'INPUT_CSV'
    RSRP_MARGIN = 'RSRP_MARGIN'
    INPUT_LINE = 'INPUT_LINE'
    DISTANCE = 'DISTANCE'
    OUTPUT_AGREGADO = 'OUTPUT_AGREGADO'
    OUTPUT_GERAL = 'OUTPUT_GERAL' 

    def tr(self, string):
        return QCoreApplication.translate('DT_Number_Elements', string)

    def createInstance(self):
        return DT_Number_Elements()

    def name(self):
        return 'DT_Number_Elements'

    def displayName(self):
        return self.tr('DT_Number Elements')
        
    def group(self) -> str:
        return 'Drive test'
    def groupId(self):
        return 'Drive test'

    def icon(self):
        icon_path = r'G:\Drives compartilhados\Qgis\Arquivo de cores\icones\DT_NS.svg'

        if os.path.exists(icon_path):
            return QIcon(icon_path)
        else:
            return QIcon()
        
    def shortHelpString(self):
        return self.tr("""
            <!-- Cabeçalho -->
            <h3 style="color: #2c3e50;">📈 Analisador de Vizinhança (Number of Elements)</h3>
            <p>
                Esta ferramenta analisa a relação entre células "Serving" e "Detected" de um drive test, consolidando a contagem de vizinhas e a qualidade do sinal em pontos ao longo de uma rota.
            </p>
            <hr>
            <!-- Funcionalidades -->
            <h4 style="color: #34495e;">Principais Funcionalidades</h4>
            <ul>
                <li><strong style="color: #2980b9;">📝 Processa</strong> logs de drive test para identificar a célula servidora e as vizinhas detectadas dentro de uma margem de RSRP.</li>
                <li><strong style="color: #2980b9;">🔗 Associa</strong> as medições processadas a pontos de análise criados ao longo de uma camada de ruas.</li>
                <li><strong style="color: #2980b9;">📊 Agrega</strong> os resultados por local, calculando o RSRP médio, o PCI servidor majoritário e a lista completa de vizinhas.</li>
                <li><strong style="color: #2980b9;">🔢 Calcula</strong> o "Number of Elements": a contagem total de células (servidora + vizinhas) em cada ponto de análise.</li>
            </ul>
            <!-- Entradas -->
            <h4 style="color: #34495e;">Entradas Necessárias</h4>
            <p>
                A ferramenta requer um <strong>Arquivo CSV</strong> com os dados do drive test, uma <strong>Camada de Ruas</strong> (linhas) e a <strong>Distância</strong> para criar os pontos de análise.
            </p>
            <!-- Resultados -->
            <h4 style="color: #34495e;">Saídas Geradas</h4>
            <p>
                Gera duas camadas: uma <strong>Principal (Agregados na Rua)</strong> com os dados consolidados por ponto na rua, e uma <strong>Secundária (Geral)</strong> com todos os pontos de medição processados do CSV.
            </p>
        
            <hr>
        
            <!-- Rodapé -->
            <p><i>Dados e Peformance</i></p>        
  
        """)
    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_CSV,
                self.tr('Arquivo CSV de entrada'),
                behavior=QgsProcessingParameterFile.File,
                fileFilter='CSV files (*.csv *.txt)'
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.RSRP_MARGIN,
                self.tr('Margem RSRP'),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=6.0
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_LINE,
                self.tr('Camada de linha (ruas)'),
                [QgsProcessing.TypeVectorLine]
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.DISTANCE,
                self.tr('Distância entre pontos na linha (m)'),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=15.0
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT_AGREGADO,
                self.tr('Agregados na Rua')
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT_GERAL,
                self.tr('Geral')
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        input_csv = self.parameterAsFile(parameters, self.INPUT_CSV, context)
        rsrp_margin = self.parameterAsDouble(parameters, self.RSRP_MARGIN, context)
        linha_layer = self.parameterAsVectorLayer(parameters, self.INPUT_LINE, context)
        dist = self.parameterAsDouble(parameters, self.DISTANCE, context)

        feedback.pushWarning("Lendo e processando o arquivo de dados (CSV ou TXT separado por tabulação)...")
        try:
            # Detecta extensão do arquivo para definir o separador
            _, ext = os.path.splitext(input_csv)
            if ext.lower() == ".txt":
                df = pd.read_csv(input_csv, sep='\t')
            else:
                df = pd.read_csv(input_csv)
        except Exception as e:
            feedback.reportError(f"Falha ao ler o arquivo de dados: {e}", fatalError=True)

        df = df.dropna(subset=['Time', 'PCI', 'RSRP', 'Lat.', 'Lon.'])
        df['PCI'] = df['PCI'].astype(int)
        
        # Verificando o nome da coluna de 'Serving'
        if 'Cell type' in df.columns:
            cell_type_col = 'Cell type'
            detected_label = 'Detected'
            serving_label = 'Serving'
        elif 'BT' in df.columns:
            cell_type_col = 'BT'
            detected_label = 'Detected beam'
            serving_label = 'Serving beam'
        else:
            raise QgsProcessingException("O arquivo CSV deve conter a coluna 'Cell Type' ou 'BT'.")

        result = []
        for (lat, lon), group in df.groupby(['Lat.', 'Lon.']):
            serving = group[group[cell_type_col] == serving_label]
            if serving.empty: continue
            pci_serving = int(serving['PCI'].iloc[0])
            rsrp_mean = serving['RSRP'].mean()
            lat = serving['Lat.'].iloc[0]
            lon = serving['Lon.'].iloc[0]
            detected = group[(group[cell_type_col] == detected_label) & (group['RSRP'] > rsrp_mean - rsrp_margin)]
            pci_detected_list = sorted(detected['PCI'].dropna().unique().astype(int).tolist())
            count_detected = len(pci_detected_list) + 1
            result.append({'Lat': lat, 'Lon': lon, 'RSRP': rsrp_mean, 'PCI': pci_serving, 'PCI_detected_list': pci_detected_list, 'n_detected': count_detected})
        
        
        if not result:
            raise QgsProcessingException("Nenhum dado válido encontrado no CSV.")

        feedback.pushInfo("Etapa 1: Criando camada de pontos de medição...")
        fields = QgsFields()
        fields.append(QgsField('Lat', QVariant.Double))
        fields.append(QgsField('Lon', QVariant.Double))
        fields.append(QgsField('RSRP', QVariant.Double))
        fields.append(QgsField('PCI', QVariant.Int))
        fields.append(QgsField('PCI_detected', QVariant.String))
        fields.append(QgsField('n_detected', QVariant.Int))
        temp_points_layer = QgsVectorLayer('Point?crs=EPSG:4326', 'Pontos de Medição', 'memory')
        provider = temp_points_layer.dataProvider()
        provider.addAttributes(fields)
        temp_points_layer.updateFields()
        for row in result:
            feature = QgsFeature()
            try:
                point_geom = QgsGeometry.fromPointXY(QgsPointXY(float(row['Lon']), float(row['Lat'])))
                feature.setGeometry(point_geom)
                feature.setAttributes([float(row['Lat']),float(row['Lon']),float(row['RSRP']), int(row['PCI']), ', '.join(map(str, row['PCI_detected_list'])), int(row['n_detected'])])
                provider.addFeature(feature)
            except (ValueError, TypeError):
                continue
        
        feedback.pushInfo("Etapa 2: Salvando a camada de pontos de medição...")
        (sink_geral, id_geral) = self.parameterAsSink(parameters, self.OUTPUT_GERAL, context, temp_points_layer.fields(), temp_points_layer.wkbType(), temp_points_layer.crs())
        if sink_geral is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT_GERAL))
        for feature in temp_points_layer.getFeatures():
            sink_geral.addFeature(feature, QgsFeatureSink.FastInsert)

        feedback.pushInfo("Etapa 3: Gerando pontos ao longo da camada de rua...")
        reproj = processing.run("native:reprojectlayer", {'INPUT': linha_layer, 'TARGET_CRS': 'EPSG:3857', 'OUTPUT': 'memory:'}, context=context)['OUTPUT']
        hub_points = processing.run("native:pointsalonglines", {'INPUT': reproj, 'DISTANCE': dist, 'OUTPUT': 'memory:'}, context=context)['OUTPUT']
        hub_points_com_id = processing.run("native:fieldcalculator", {'INPUT': hub_points, 'FIELD_NAME': 'hub_id', 'FIELD_TYPE': 1, 'FORMULA': '@id', 'OUTPUT': 'memory:'}, context=context)['OUTPUT']

        feedback.pushInfo("Etapa 4: Criando linhas de distância para os pontos mais próximos na rua...")
        temp_points_reproj = processing.run("native:reprojectlayer", {'INPUT': temp_points_layer, 'TARGET_CRS': 'EPSG:3857', 'OUTPUT': 'memory:'}, context=context)['OUTPUT']
        distance_lines = processing.run("qgis:distancetonearesthublinetohub", {'INPUT': temp_points_reproj, 'HUBS': hub_points_com_id, 'FIELD': 'hub_id', 'UNIT': 0, 'OUTPUT': 'memory:'}, context=context)['OUTPUT']

        feedback.pushInfo("Etapa 5: Criando buffers de 0.5m ao redor dos pontos da rua...")
        hub_buffers = processing.run("native:buffer", {'INPUT': hub_points_com_id, 'DISTANCE': 0.5, 'DISSOLVE': False, 'OUTPUT': 'memory:'}, context=context)['OUTPUT']

        feedback.pushInfo("Etapa 6: Unindo atributos das linhas de distância aos buffers...")
        joined_layer = processing.run("native:joinattributesbylocation", {'INPUT': hub_buffers, 'JOIN': distance_lines, 'PREDICATE': [0], 'JOIN_FIELDS': ['RSRP', 'PCI', 'PCI_detected', 'HubName'], 'METHOD': 0, 'DISCARD_NONMATCHING': True, 'PREFIX': '', 'OUTPUT': 'memory:'}, context=context)['OUTPUT']

        feedback.pushInfo("Etapa 7: Convertendo buffers de volta para pontos...")
        centroids_metric = processing.run("native:centroids", {'INPUT': joined_layer, 'ALL_PARTS': False, 'OUTPUT': 'memory:'}, context=context)['OUTPUT']

        feedback.pushInfo("Etapa 8: Agregando resultados finais com Pandas...")
        
        features = centroids_metric.getFeatures()
        data = [{'ID': f['HubName'], 'RSRP': f['RSRP'], 'PCI': f['PCI'], 'PCI_detected': f['PCI_detected'], 'geom': f.geometry()} for f in features]
        df_centroids = pd.DataFrame(data)

        def aggregate_pci(series):
            all_pcis = set()
            for item in series.dropna():
                if isinstance(item, str) and item:
                    try:
                        all_pcis.update(map(int, item.replace(' ', '').split(',')))
                    except (ValueError, TypeError):
                        continue
            return sorted(list(all_pcis))

        aggregated_df = df_centroids.groupby('ID').agg(
            RSRP_final=('RSRP', 'mean'),
            PCI_final=('PCI', lambda x: x.mode()[0] if not x.mode().empty else None),
            PCI_detected_list=('PCI_detected', aggregate_pci),
            geom=('geom', 'first')
        ).reset_index()

        aggregated_df['n_detected'] = aggregated_df.apply(
            lambda row: len(row['PCI_detected_list']) + (1 if row['PCI_final'] is not None and row['PCI_final'] not in row['PCI_detected_list'] else 0),
            axis=1
        )
        aggregated_df['PCI_detected_list'] = aggregated_df['PCI_detected_list'].apply(lambda x: ', '.join(map(str, x)))

        feedback.pushInfo("Etapa 9: Criando camada de saída agregada...")
        final_fields = QgsFields()
        final_fields.append(QgsField('ID', QVariant.String))
        final_fields.append(QgsField('Latitude', QVariant.Double, len=10, prec=8))
        final_fields.append(QgsField('Longitude', QVariant.Double, len=10, prec=8))
        final_fields.append(QgsField('RSRP_final', QVariant.Double))
        final_fields.append(QgsField('PCI_final', QVariant.Int))
        final_fields.append(QgsField('PCI_detected_list', QVariant.String))
        final_fields.append(QgsField('n_detected', QVariant.Int))

        # --- MELHORIA: Define o CRS de saída como WGS84 desde o início ---
        crs_wgs84 = QgsCoordinateReferenceSystem('EPSG:4326')
        (sink_agregado,id_agregado) = self.parameterAsSink(parameters, self.OUTPUT_AGREGADO, context, final_fields, QgsWkbTypes.Point, crs_wgs84)
        if sink_agregado is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT_AGREGADO))

        # --- MELHORIA: Prepara a transformação de coordenadas ---
        source_crs = centroids_metric.crs()
        transform = QgsCoordinateTransform(source_crs, crs_wgs84, QgsProject.instance())

        for index, row in aggregated_df.iterrows():
            if feedback.isCanceled(): break
            
            feat = QgsFeature(final_fields)
            
            # --- MELHORIA: Transforma a geometria e extrai as coordenadas ---
            geom_metric = row['geom']
            geom_wgs84 = QgsGeometry(geom_metric)
            geom_wgs84.transform(transform)
            
            point_wgs84 = geom_wgs84.asPoint()
            longitude = point_wgs84.x()
            latitude = point_wgs84.y()
            
            feat.setGeometry(geom_wgs84)
            feat.setAttributes([
                row['ID'],
                latitude,
                longitude,
                row['RSRP_final'],
                row['PCI_final'],
                row['PCI_detected_list'],
                row['n_detected']
                
            ])
            sink_agregado.addFeature(feat, QgsFeatureSink.FastInsert)

            
        # --- MELHORIA: Aplica simbologia personalizada às camadas de saída ---
         
        feedback.pushInfo("Etapa 10: Aplicando Simbologia nas camadas de pontos...")
        qml_path = r'G:\Drives compartilhados\Qgis\Arquivo de cores\Otimizar_Number_of_Elements.qml'
        # Para OUTPUT_AGREGADO
        layer_agregado = context.getMapLayer(id_agregado)
        if layer_agregado and os.path.exists(qml_path):
            layer_agregado.loadNamedStyle(qml_path)
            layer_agregado.triggerRepaint()
            
        # Para OUTPUT_GERAL
        layer_geral = context.getMapLayer(id_geral)
        if layer_geral and os.path.exists(qml_path):
            layer_geral.loadNamedStyle(qml_path)
            layer_geral.triggerRepaint()
            
        feedback.pushInfo("Processo concluído com sucesso.")
        return {
            self.OUTPUT_AGREGADO: id_agregado,
            self.OUTPUT_GERAL: id_geral
        }
