import matplotlib
# The backend is set in the previous cell and cannot be changed here.
# matplotlib.use('Qt5Agg')

from qgis.utils import iface
from qgis.PyQt.QtWidgets import QDialog, QWidget, QVBoxLayout, QComboBox, QLabel, QFrame, QHBoxLayout, QGridLayout
from qgis.PyQt.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
import numpy as np
from qgis.core import QgsProject, QgsVectorLayer
import math

# Aplica um estilo visual mais agradável aos gráficos
plt.style.use('seaborn-v0_8-whitegrid')

# --- 1. DEFINIÇÃO DA CLASSE DA JANELA DE DIÁLOGO ---

class ChartDialog(QDialog):
    """
    Esta classe cria uma janela de diálogo (QDialog) com um histograma
    interativo que se atualiza com base na camada, campo e feições selecionadas.
    """
    def __init__(self, parent=iface.mainWindow()):
        """Construtor da janela."""
        super(ChartDialog, self).__init__(parent)
        self.setWindowTitle("Análise Gráfica")
        self.setMinimumSize(600, 500) # Define um tamanho mínimo para a janela

        self.camada_conectada = None
        self._bar_categories = [] # To store the categories for the bars

        # Configura a interface e os sinais
        self._setup_ui()
        self._connect_signals()

        # Preenche os dados iniciais
        self.preencher_camadas()

    def _setup_ui(self):
        """Creates and organizes the widgets inside the window."""
        self.layout = QVBoxLayout(self)

        # Layout de grade para os ComboBoxes para alinhamento perfeito
        grid_layout_opcoes = QGridLayout()

        # Camada
        grid_layout_opcoes.addWidget(QLabel("Camada:"), 0, 0)
        self.combo_camada = QComboBox()
        self.combo_camada.setStyleSheet("border: 1px solid black;")
        grid_layout_opcoes.addWidget(self.combo_camada, 0, 1)

        # Campo
        grid_layout_opcoes.addWidget(QLabel("Campo:"), 1, 0)
        self.combo_campo = QComboBox()
        self.combo_campo.setStyleSheet("border: 1px solid black;")
        grid_layout_opcoes.addWidget(self.combo_campo, 1, 1)

        # Tipo de Gráfico
        grid_layout_opcoes.addWidget(QLabel("Gráfico:"), 2, 0)
        self.combo_tipo_grafico = QComboBox()
        self.combo_tipo_grafico.setStyleSheet("border: 1px solid black;")
        self.combo_tipo_grafico.addItems(["Histograma", "Gráfico de Barras", "Gráfico de Pizza"])
        grid_layout_opcoes.addWidget(self.combo_tipo_grafico, 2, 1)
        
        # Ajusta a expansão das colunas para que a primeira (rótulos) não se expanda
        grid_layout_opcoes.setColumnStretch(2, 1)
        self.layout.addLayout(grid_layout_opcoes)

        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setFrameShadow(QFrame.Sunken)
        self.layout.addWidget(separator)

        # Cria a figura e o canvas do Matplotlib
        self.fig, self.ax = plt.subplots(figsize=(6, 4))
        self.canvas = FigureCanvas(self.fig)
        self.layout.addWidget(self.canvas)
        
        # Label no display 
        self.label_stats = QLabel("")
        self.layout.addWidget(self.label_stats)
        self.label_stats.setAlignment(Qt.AlignLeft)
        self.label_stats.setStyleSheet("border: 1px solid black; padding: 5px;background-color: white;")



    def _connect_signals(self):
        """Conecta os sinais dos widgets às suas funções (slots)."""
        self.combo_camada.currentIndexChanged.connect(self.preencher_campos)
        self.combo_campo.currentIndexChanged.connect(self.atualizar_grafico)
        self.combo_tipo_grafico.currentIndexChanged.connect(self.atualizar_grafico)
        QgsProject.instance().layersAdded.connect(self.preencher_camadas)
        QgsProject.instance().layersRemoved.connect(self.preencher_camadas)
        # Conectar o evento de clique do mouse no canvas
        self.canvas.mpl_connect('button_press_event', self._on_bar_click)


    def preencher_camadas(self, layers=None):
        """Preenche o ComboBox com as camadas vetoriais do projeto."""
        self.combo_camada.blockSignals(True)
        self.combo_camada.clear()
        camadas = [
            layer.name() for layer in QgsProject.instance().mapLayers().values()
            if isinstance(layer, QgsVectorLayer)
        ]
        self.combo_camada.addItems(camadas)
        self.combo_camada.blockSignals(False)
        self.preencher_campos()

    def preencher_campos(self):
        """Preenche o ComboBox com os campos da camada selecionada."""
        if self.camada_conectada:
            try:
                self.camada_conectada.selectionChanged.disconnect(self.atualizar_grafico)
            except TypeError:
                pass

        self.combo_campo.clear()
        nome_camada = self.combo_camada.currentText()
        if not nome_camada:
            self.atualizar_grafico()
            return

        camada = QgsProject.instance().mapLayersByName(nome_camada)
        if not camada:
             self.atualizar_grafico()
             return

        camada = camada[0]
        campos = [field.name() for field in camada.fields()]
        self.combo_campo.addItems(campos)

        camada.selectionChanged.connect(self.atualizar_grafico)
        self.camada_conectada = camada
        self.atualizar_grafico()

    def atualizar_grafico(self):
        """Desenha ou atualiza o gráfico com base nos dados e tipo selecionados."""
        nome_camada = self.combo_camada.currentText()
        campo = self.combo_campo.currentText()
        tipo_grafico = self.combo_tipo_grafico.currentText()

        self.ax.clear()
        self._bar_categories = [] # Clear categories on update

        if not nome_camada or not campo:
            self.ax.set_title("Selecione uma camada e um campo")
            self.label_stats.setText("")
            self.canvas.draw()
            return

        camada_list = QgsProject.instance().mapLayersByName(nome_camada)
        if not camada_list:
            self.ax.set_title(f"Camada '{nome_camada}' não encontrada")
            self.label_stats.setText("")
            self.canvas.draw()
            return
        camada = camada_list[0]


        feicoes = camada.selectedFeatures() if camada.selectedFeatureCount() > 0 else camada.getFeatures()

        valores = []
        for f in feicoes:
            valor = f[campo]
            if valor is not None:
                if isinstance(valor, str) and ',' in valor:
                    elementos = valor.split(',')
                    for elemento in elementos:
                        try:
                            valores.append(float(elemento.strip()))
                        except (ValueError, TypeError):
                            continue
                else:
                    try:
                        valores.append(float(valor))
                    except (ValueError, TypeError):
                        continue

        if valores:
            titulo = f"Distribuição de '{campo}'"
            subtitulo = "Todas as Feições"
            if camada.selectedFeatureCount() > 0:
                subtitulo = f"{camada.selectedFeatureCount()} Feições Selecionadas"

            self.ax.set_title(f"{titulo}\n({subtitulo})")

            # GRAFICO DE HISTOGRAMA
            if tipo_grafico == 'Histograma':
                # Convert values to float for histogram if they are not strings
                numeric_valores = [v for v in valores if isinstance(v, (int, float))]

                if not numeric_valores:
                    self.ax.set_title("Sem dados numéricos válidos para histograma")
                    self.label_stats.setText("")
                    self.canvas.draw()
                    return

                media = np.mean(numeric_valores)
                mediana = np.median(numeric_valores)
                desvio_padrao = np.std(numeric_valores)
                contagem = len(numeric_valores)
                valor_minimo = np.min(numeric_valores) # Adiciona cálculo do mínimo
                valor_maximo = np.max(numeric_valores) # Adiciona cálculo do máximo


                # Regra de Sturges para calcular o número de bins
                if contagem > 0:
                    num_bins = math.ceil(1 + 3.322 * math.log10(contagem))
                else:
                    num_bins = 10 # Número padrão se não houver dados

                n, bins, patches = self.ax.hist(numeric_valores, bins=num_bins, color='skyblue', edgecolor='black', alpha=0.7)
                self.ax.axvline(media, color='red', linestyle='dashed', linewidth=2, label=f'Média: {media:.2f}')
                self.ax.set_xlabel(f"Valores de {campo}")
                self.ax.set_ylabel("Frequência")

                # Adicionar rótulos de dados nas barras (opcional, para evitar sobreposição em muitos bins)
                if num_bins < 30: # Limite para exibir os rótulos
                    for count, patch in zip(n, patches):
                        height = patch.get_height()
                        if height > 0: # Adiciona rótulo apenas se a altura for maior que 0
                            self.ax.text(patch.get_x() + patch.get_width() / 2., height,
                                         '%d' % int(count),
                                         ha='center', va='bottom')

                stats_text = (
                        f"Estatísticas ({campo}):\n" # Título para as estatísticas
                        f"  Contagem: {contagem}\n"
                        f"  Média: {media:.2f}\n"
                        f"  Mediana: {mediana:.2f}\n"
                        f"  Desvio Padrão: {desvio_padrao:.2f}\n"
                        f"  Mínimo: {valor_minimo:.2f}\n" # Exibe o mínimo
                        f"  Máximo: {valor_maximo:.2f}\n" # Exibe o máximo
                        f"  Número de Bins (Sturges): {num_bins}"
                    )
                self.label_stats.setText(stats_text)

            # GRAFICO DE BARRAS
            elif tipo_grafico == 'Gráfico de Barras':
                # Ensure values are treated as strings for categorical data
                string_valores = [str(v) for v in valores]
                categorias, contagens = np.unique(string_valores, return_counts=True)

                # Ordenar categorias e contagens por contagem (decrescente)
                sorted_indices = np.argsort(contagens)[::-1]
                self._bar_categories = [categorias[i] for i in sorted_indices]
                contagens_ordenadas = [contagens[i] for i in sorted_indices]


                bars = self.ax.bar(range(len(self._bar_categories)), contagens_ordenadas, color='skyblue', edgecolor='black', alpha=0.7)
                self.ax.set_ylabel("Contagem de Ocorrências")
                self.ax.set_xlabel(f"Valores Únicos de {campo}")
                self.ax.set_xticks(range(len(self._bar_categories)))
                self.ax.set_xticklabels([str(c) for c in self._bar_categories])
                if len(self._bar_categories) > 10:
                    plt.setp(self.ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")

                # Adicionar rótulos de dados nas barras
                for bar in bars:
                    yval = bar.get_height()
                    if yval > 0: # Adiciona rótulo apenas se a altura for maior que 0
                        self.ax.text(bar.get_x() + bar.get_width()/2., yval, int(yval), va='bottom', ha='center') # center alignment

                self.label_stats.setText(f"Estatísticas ({campo}):\n  Contagem Total: {len(valores)}")


            # GRÁFICO DE PIZZA (Placeholder for future implementation)
            elif tipo_grafico == 'Gráfico de Pizza':
                 self.ax.set_title("Gráfico de Pizza não implementado")
                 self.label_stats.setText("")


        else:
            self.ax.set_title("Sem dados válidos para exibir")
            self.label_stats.setText("") # Limpa as estatísticas se não houver dados


        self.fig.tight_layout()
        self.canvas.draw()


    def _on_bar_click(self, event):
        """Handles click events on the bar chart."""
        if self.combo_tipo_grafico.currentText() == 'Gráfico de Barras' and event.xdata is not None and event.ydata is not None:
            clicked_x, clicked_y = event.xdata, event.ydata

            for i, bar in enumerate(self.ax.patches):
                # Check if the click is within the bar's bounds
                if bar.get_x() <= clicked_x <= bar.get_x() + bar.get_width() and \
                   bar.get_y() <= clicked_y <= bar.get_height():
                    if i < len(self._bar_categories): # Ensure index is within bounds
                        clicked_category = self._bar_categories[i]
                        print(f"Clicked category: {clicked_category}")

                        # Get the current layer and field
                        nome_camada = self.combo_camada.currentText()
                        campo = self.combo_campo.currentText()

                        if not nome_camada or not campo:
                            print("No layer or field selected.")
                            return

                        camada = QgsProject.instance().mapLayersByName(nome_camada)
                        if not camada:
                            print(f"Layer '{nome_camada}' not found.")
                            return
                        layer = camada[0]

                        # Clear previous selection
                        layer.removeSelection()

                        # Construct the filter expression
                        # Handle potential string values by quoting
                        if isinstance(clicked_category, str):
                            filter_expression = f'"{campo}" = \'{clicked_category.replace("'", "''")}\'' # Handle single quotes in string
                        else:
                            filter_expression = f'"{campo}" = {clicked_category}'

                        print(f"Filter expression: {filter_expression}")

                        # Select features by expression
                        layer.selectByExpression(filter_expression)
                        print(f"Selected features for category: {clicked_category}")

                        break # Stop after finding the first bar under the click

    def closeEvent(self, event):
        """Garante que os sinais sejam desconectados quando a janela é fechada."""
        if self.camada_conectada:
            try:
                self.camada_conectada.selectionChanged.disconnect(self.atualizar_grafico)
            except TypeError:
                pass
        QgsProject.instance().layersAdded.disconnect(self.preencher_camadas)
        QgsProject.instance().layersRemoved.disconnect(self.preencher_camadas)
        super(ChartDialog, self).closeEvent(event)

# --- 2. EXECUÇÃO: Cria e mostra a janela de diálogo ---

# Variável global para guardar a referência da janela
minha_janela_grafico = None

def abrir_janela_grafico():
    """Função para criar e mostrar a janela, evitando duplicados."""
    global minha_janela_grafico
    # Se a janela já existe, apenas a traz para a frente
    if minha_janela_grafico and minha_janela_grafico.isVisible():
        minha_janela_grafico.raise_()
        minha_janela_grafico.activateWindow()
    else:
        # Se não, cria uma nova
        minha_janela_grafico = ChartDialog()
        minha_janela_grafico.show()

# Executa a função para abrir a janela
#abrir_janela_grafico()