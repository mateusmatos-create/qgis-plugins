# --- Importações da Biblioteca Padrão do Python ---
import os
import random
from typing import Any, Optional

# --- Importações de Terceiros ---
import pandas as pd

# --- Importações do QGIS ---
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterDefinition,
    QgsCoordinateReferenceSystem,
    QgsExpression,
    QgsProcessingException,
    QgsProcessingParameterFeatureSink,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsFeatureSink,
    QgsWkbTypes 
)
from qgis import processing
from qgis.PyQt.QtCore import QVariant 


class DT_UE_Measurement(QgsProcessingAlgorithm):

    def initAlgorithm(self, config: Optional[dict[str, Any]] = None):
        # --- Definição dos parâmetros de entrada da ferramenta ---
        self.addParameter(QgsProcessingParameterVectorLayer('camada_de_ruas', 'Camada de ruas', types=[QgsProcessing.TypeVectorLine], defaultValue=None))
        self.addParameter(QgsProcessingParameterNumber('distancia_entre_pontos_metros', 'Distancia entre pontos (metros)', type=QgsProcessingParameterNumber.Double, defaultValue=15))
        
        # Parâmetros avançados (opcionais) para filtrar a análise por uma área específica.
        param = QgsProcessingParameterBoolean('otimizao_por_regio', 'Otimização por região?', optional=True, defaultValue=False)
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)
        param = QgsProcessingParameterVectorLayer('poligono_da_regiao', 'Poligono da Regiao', optional=True, types=[QgsProcessing.TypeVectorPolygon], defaultValue=None)
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)
        
        self.addParameter(QgsProcessingParameterVectorLayer('pontos_drive_test', 'Pontos Drive Test', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        
        # --- Definição das saídas da ferramenta ---
        self.addParameter(QgsProcessingParameterFileDestination('Csv_otimizado', 'CSV_Otimizado', fileFilter='CSV (*.csv)', createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('OUTPUT_LAYER','Camada de pontos otimizada',QgsProcessing.TypeVectorPoint))
        
        # Parâmetro para permitir que o usuário aplique um estilo visual (QML) à camada de saída.
        simbologia_options = ['Nenhuma', 'RSRP', 'RSRQ', 'SINR', 'Throughput DL', 'Throughput UL']
        self.addParameter(QgsProcessingParameterEnum('SIMBOLOGIA_TIPO','Aplicar simbologia por',options=simbologia_options,allowMultiple=False,defaultValue=0))
        
    def processAlgorithm(self, parameters: dict[str, Any], context: QgsProcessingContext, model_feedback: QgsProcessingFeedback) -> dict[str, Any]:
        # Configura o feedback para múltiplos passos, permitindo uma barra de progresso mais detalhada.
        feedback = QgsProcessingMultiStepFeedback(13, model_feedback)
        results = {}
        outputs = {}

        # --- Recupera os parâmetros fornecidos pelo usuário na interface do QGIS ---
        feedback.pushWarning("Lendo parâmetros de entrada...")
        otimizacao_por_regiao = parameters['otimizao_por_regio']
        poligono_regiao = self.parameterAsVectorLayer(parameters, 'poligono_da_regiao', context)
        simbologia_tipo_index = self.parameterAsEnum(parameters, 'SIMBOLOGIA_TIPO', context)
        simbologia_options = ['Nenhuma', 'RSRP', 'RSRQ', 'SINR', 'Throughput DL', 'Throughput UL']
        tipo_simbologia = simbologia_options[simbologia_tipo_index]
        
        # --- Etapa 1: Verificar o tipo de tecnologia (4G/5G) ---
        feedback.pushInfo("ETAPA 1/12: Detectando tipo de tecnologia (4G/5G)...")
        pontos_dt_layer = self.parameterAsVectorLayer(parameters, 'pontos_drive_test', context)
        if not pontos_dt_layer:
            raise QgsProcessingException("A camada 'Pontos Drive Test' de entrada não foi fornecida.")
        
        # A detecção é baseada na presença do campo 'RSRQ', que é específico do 4G.
        field_names = [field.name().upper() for field in pontos_dt_layer.fields()]
        if 'RSRQ' in field_names:
            tipo_rede = '4G'
        else:
            tipo_rede = '5G'
        feedback.pushWarning(f"Tecnologia detectada: {tipo_rede}")
        
        # --- Etapa 2: Corrigir geometrias das camadas de entrada ---
        # Este passo é crucial para evitar erros em operações geoespaciais posteriores.
        feedback.setCurrentStep(1)
        feedback.pushInfo("ETAPA 2/12: Corrigindo geometrias das camadas de entrada...")
        
        alg_params_fix_ruas = {'INPUT': parameters['camada_de_ruas'], 'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
        outputs['RuasCorrigidas'] = processing.run('native:fixgeometries', alg_params_fix_ruas, context=context, is_child_algorithm=True)

        alg_params_fix_pontos = {'INPUT': parameters['pontos_drive_test'], 'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
        outputs['PontosCorrigidos'] = processing.run('native:fixgeometries', alg_params_fix_pontos, context=context, is_child_algorithm=True)

        # --- Etapa 3: Criar pasta para arquivos temporários ---
        feedback.setCurrentStep(2)
        feedback.pushInfo("ETAPA 3/12: Configurando ambiente de trabalho temporário...")
        try:
            home_dir = os.path.expanduser("~")
            temp_dir = os.path.join(home_dir, 'Desktop', 'Qgis_Temporarios')
            os.makedirs(temp_dir, exist_ok=True)
            feedback.pushInfo(f"Pasta para arquivos intermediários: {temp_dir}")
        except Exception as e:
            raise QgsProcessingException(f"Não foi possível criar a pasta temporária: {e}")

        # --- Etapa 4: Gerar pontos de análise ao longo das ruas ---
        feedback.setCurrentStep(3)
        feedback.pushInfo("ETAPA 4/12: Gerando pontos de análise ao longo das ruas...")
        
        # ATENÇÃO: Esta conversão de metros para graus é uma aproximação e só funciona bem perto do Equador.
        # Para maior precisão, o ideal seria reprojetar as camadas para um CRS projetado (ex: UTM).
        distancia_em_grau = parameters['distancia_entre_pontos_metros'] / 111319.49079327358
        feedback.pushWarning(f"INFO: Distância entre pontos convertida para graus: {distancia_em_grau:.6f} graus")

        alg_params_points_along = {'DISTANCE': distancia_em_grau,'INPUT': outputs['RuasCorrigidas']['OUTPUT'],'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
        outputs['PointsAlongGeometry'] = processing.run('native:pointsalonglines', alg_params_points_along, context=context, is_child_algorithm=True)
        
        # --- Etapa 5: Preparar os pontos de análise ---
        feedback.setCurrentStep(4)
        feedback.pushInfo("ETAPA 5/12: Preparando os pontos de análise (Limpando campos e adicionando ID)...")
        
        # Remove a coluna 'fid' que pode causar conflitos em junções futuras.
        alg_params_delete_fid = {'INPUT': outputs['PointsAlongGeometry']['OUTPUT'], 'COLUMN': ['fid'], 'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
        outputs['PointsCleaned'] = processing.run('native:deletecolumn', alg_params_delete_fid, context=context, is_child_algorithm=True)

        # Adiciona um ID único para cada ponto de análise, que será usado para agrupar os dados.
        alg_params_calc_id = {'FIELD_NAME': 'ID','FIELD_TYPE': 1,'FORMULA': '@id','INPUT': outputs['PointsCleaned']['OUTPUT'],'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
        outputs['FieldCalculator'] = processing.run('native:fieldcalculator', alg_params_calc_id, context=context, is_child_algorithm=True)

        # --- Etapa 6: Adicionar coordenadas e criar buffers ---
        feedback.setCurrentStep(5)
        feedback.pushInfo("ETAPA 6/12: Adicionando coordenadas X/Y aos pontos de análise...")
        alg_params_add_xy = {'CRS': QgsCoordinateReferenceSystem('EPSG:4326'),'INPUT': outputs['FieldCalculator']['OUTPUT'],'PREFIX': '','OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
        outputs['AdicionarCamposXyCamada'] = processing.run('native:addxyfields', alg_params_add_xy, context=context, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        feedback.pushInfo("ETAPA 7/12: Criando área de influência (buffer) para cada ponto de análise...")
        buffer_path = os.path.join(temp_dir, f'buffer_{random.randint(1, 1000000)}.gpkg')
        alg_params_buffer = {'DISTANCE': 0.000005, 'INPUT': outputs['AdicionarCamposXyCamada']['OUTPUT'],'OUTPUT': buffer_path}
        outputs['Buffer'] = processing.run('native:buffer', alg_params_buffer, context=context, is_child_algorithm=True)

        camada_final_para_analise = None
        
        # --- Etapa 7: Associação de dados (Lógica específica por tecnologia) ---
        feedback.setCurrentStep(7)
        feedback.pushInfo(f"ETAPA 8/12: Associando medições de Drive Test ({tipo_rede}) aos pontos de análise...")
        
        if tipo_rede == '5G':
            # Renomeia campos para um padrão consistente, facilitando a análise posterior.
            feedback.pushInfo("INFO: Renomeando campos do Drive Test 5G para padronização...")
            alg_params_refactor = {
                'FIELDS_MAPPING': [
                    {'alias': None,'comment': None,'expression': '"fid"','length': 0,'name': 'fid','precision': 0,'sub_type': 0,'type': 4,'type_name': 'int8'},
                    {'alias': None,'comment': None,'expression': '"Time"','length': 0,'name': 'Time','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                    {'alias': None,'comment': None,'expression': '"Lon."','length': 0,'name': 'Lon.','precision': 0,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                    {'alias': None,'comment': None,'expression': '"Lat."','length': 0,'name': 'Lat.','precision': 0,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                    {'alias': None,'comment': None,'expression': '"PCI"','length': 0,'name': 'PCI','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                    {'alias': None,'comment': None,'expression': '"NR-ARFCN"','length': 0,'name': 'NR-ARFCN','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                    {'alias': None,'comment': None,'expression': '"Band"','length': 0,'name': 'Band','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                    {'alias': None,'comment': None,'expression': '"Band (MHz)"','length': 0,'name': 'Band (MHz)','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                    {'alias': None,'comment': None,'expression': '"RSRP"','length': 0,'name': 'RSRP','precision': 0,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                    {'alias': None,'comment': None,'expression': '"RSSI"','length': 0,'name': 'RSSI','precision': 0,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                    {'alias': None,'comment': None,'expression': '"SINR"','length': 0,'name': 'SINR','precision': 0,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                    {'alias': None,'comment': None,'expression': '"App. rate DL"','length': 0,'name': 'App. rate DL','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                    {'alias': None,'comment': None,'expression': '"App. rate UL"','length': 0,'name': 'App. rate UL','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                    {'alias': None,'comment': None,'expression': '"PDSCH modulation codeword 0"','length': 0,'name': 'Modulation DL','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                    {'alias': None,'comment': None,'expression': '"PUSCH modulation for codeword 0"','length': 0,'name': 'Modulation UL','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                    {'alias': None,'comment': None,'expression': '"RI"','length': 0,'name': 'RI','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'}
                ],
                'INPUT': outputs['PontosCorrigidos']['OUTPUT'], 'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['RefactorFields5g'] = processing.run('native:refactorfields', alg_params_refactor, context=context, is_child_algorithm=True)
            pontos_para_processar = outputs['RefactorFields5g']['OUTPUT']
            
            # Filtra os pontos de DT se uma região foi fornecida.
            if otimizacao_por_regiao and poligono_regiao:
                feedback.pushInfo("INFO: Filtrando pontos 5G pela região fornecida...")
                alg_params_extracao = {'INPUT': pontos_para_processar,'INTERSECT': poligono_regiao,'PREDICATE': [0],'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
                outputs['ExtrairPorLocalizao5g'] = processing.run('native:extractbylocation', alg_params_extracao, context=context, is_child_algorithm=True)
                pontos_para_processar = outputs['ExtrairPorLocalizao5g']['OUTPUT']
            
            feedback.setCurrentStep(8)
            feedback.pushInfo("ETAPA 9/12: Calculando distância entre pontos de medição e de análise...")
            dist_path_5g = os.path.join(temp_dir, f'dist_5g_{random.randint(1, 1000000)}.gpkg')
            alg_params_dist = {'FIELD': 'ID','HUBS': outputs['AdicionarCamposXyCamada']['OUTPUT'],'INPUT': pontos_para_processar,'UNIT': 0,'OUTPUT': dist_path_5g}
            outputs['Distncia5g'] = processing.run('qgis:distancetonearesthublinetohub', alg_params_dist, context=context, is_child_algorithm=True)
            
            feedback.setCurrentStep(9)
            feedback.pushInfo("ETAPA 10/12: Juntando atributos por localização...")
            alg_params_join = {'DISCARD_NONMATCHING': True,'INPUT': outputs['Buffer']['OUTPUT'],'JOIN': outputs['Distncia5g']['OUTPUT'],'JOIN_FIELDS': ['RSRP','PCI','SINR','App. rate DL','App. rate UL','Modulation DL','Modulation UL', 'RI'],'METHOD': 0,'PREDICATE': [0],'PREFIX': '','OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
            outputs['JoinAttributes5g'] = processing.run('native:joinattributesbylocation', alg_params_join, context=context, is_child_algorithm=True)
            
            feedback.setCurrentStep(10)
            feedback.pushInfo("ETAPA 11/12: Consolidando geometria da camada unida...")
            alg_params_centroids = {'INPUT': outputs['JoinAttributes5g']['OUTPUT'], 'ALL_PARTS': False, 'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
            outputs['Centroids5g'] = processing.run('native:centroids', alg_params_centroids, context=context, is_child_algorithm=True)
            camada_final_para_analise = outputs['Centroids5g']['OUTPUT']
            
        else: # Lógica para 4G
            pontos_para_processar = outputs['PontosCorrigidos']['OUTPUT']

            if otimizacao_por_regiao and poligono_regiao:
                feedback.pushInfo("INFO: Filtrando pontos 4G pela região fornecida...")
                alg_params_extracao = {'INPUT': pontos_para_processar,'INTERSECT': poligono_regiao,'PREDICATE': [0],'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
                outputs['ExtrairPorLocalizao4g'] = processing.run('native:extractbylocation', alg_params_extracao, context=context, is_child_algorithm=True)
                pontos_para_processar = outputs['ExtrairPorLocalizao4g']['OUTPUT']
            
            feedback.setCurrentStep(8)
            feedback.pushInfo("ETAPA 9/12: Calculando distância entre pontos de medição e de análise...")
            dist_path_4g = os.path.join(temp_dir, f'dist_4g_{random.randint(1, 1000000)}.gpkg')
            alg_params_dist = {'FIELD': 'ID','HUBS': outputs['AdicionarCamposXyCamada']['OUTPUT'],'INPUT': pontos_para_processar,'UNIT': 0,'OUTPUT': dist_path_4g}
            outputs['Distncia4g'] = processing.run('qgis:distancetonearesthublinetohub', alg_params_dist, context=context, is_child_algorithm=True)

            feedback.setCurrentStep(9)
            feedback.pushInfo("ETAPA 10/12: Juntando atributos por localização...")
            alg_params_join = {'DISCARD_NONMATCHING': True,'INPUT': outputs['Buffer']['OUTPUT'],'JOIN': outputs['Distncia4g']['OUTPUT'],'JOIN_FIELDS': ['RSRP','PCI','RSRQ','SNR','App. rate DL','App. rate UL','Modulation 0', 'Rank'],'METHOD': 0,'PREDICATE': [0],'PREFIX': '','OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
            outputs['JoinAttributes4g'] = processing.run('native:joinattributesbylocation', alg_params_join, context=context, is_child_algorithm=True)
            
            feedback.setCurrentStep(10)
            feedback.pushInfo("ETAPA 11/12: Consolidando geometria da camada unida...")
            alg_params_centroids = {'INPUT': outputs['JoinAttributes4g']['OUTPUT'], 'ALL_PARTS': False, 'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT}
            outputs['Centroids4g'] = processing.run('native:centroids', alg_params_centroids, context=context, is_child_algorithm=True)
            camada_final_para_analise = outputs['Centroids4g']['OUTPUT']

        # --- Etapa 8: Análise Estatística com Pandas ---
        feedback.setCurrentStep(11)
        feedback.pushInfo("ETAPA 12/12: Executando análise estatística com Pandas...")
        output_csv_path = self.parameterAsFileOutput(parameters, 'Csv_otimizado', context)

        feedback.pushInfo("INFO: Convertendo camada para DataFrame para análise...")
        camada_vetorial = context.takeResultLayer(camada_final_para_analise)
        if not camada_vetorial:
             raise QgsProcessingException("A camada intermediária para análise não pôde ser carregada.")
        
        # Converte feições da camada em uma lista de dados para o DataFrame.
        features = camada_vetorial.getFeatures()
        lista_dados = []
        colunas = [field.name() for field in camada_vetorial.fields()] + ['geom']
        for feat in features:
            atributos = feat.attributes()
            geometria_wkt = feat.geometry().asWkt()
            lista_dados.append(atributos + [geometria_wkt])
        if not lista_dados:
            raise QgsProcessingException("Nenhum dado foi associado. Verifique a sobreposição das camadas de entrada.")
            
        df = pd.DataFrame(lista_dados, columns=colunas)
        feedback.pushWarning(f"INFO: DataFrame criado com {len(df)} medições para processar.")

        # Define os nomes das colunas com base na tecnologia.
        id_col = 'ID'
        rsrp_col = 'RSRP'
        pci_col = 'PCI'
        app_dl_col = 'App. rate DL'
        app_ul_col = 'App. rate UL'

        if tipo_rede == '4G':
            sinr_col = 'SNR'
            rsrq_col = 'RSRQ'
            rank_col = 'Rank'
            modulation_col = 'Modulation 0'
            estatisticas_cols = [rsrp_col, pci_col, sinr_col, rsrq_col, app_dl_col, app_ul_col, rank_col]
        else: # 5G
            sinr_col = 'SINR'
            rsrq_col = None
            rank_col = 'RI'
            modulation_dl_col = 'Modulation DL'
            modulation_ul_col = 'Modulation UL'
            estatisticas_cols = [rsrp_col, pci_col, sinr_col, app_dl_col, app_ul_col, rank_col]

        # Garante que as colunas de métricas sejam numéricas.
        for col in estatisticas_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')

        # Agrupa todas as medições por cada ponto de análise (usando o ID).
        df = df.dropna(subset=[id_col, rsrp_col])
        grouped = df.groupby(id_col)
        feedback.pushInfo("INFO: Calculando estatísticas (média, max, min, etc.)...")

        # Dicionário para calcular as estatísticas agregadas.
        agg_dict = {
            rsrp_col: ['count', 'max', 'min', 'mean', 'median', 'std'],
            sinr_col: ['max', 'min', 'mean', 'median', 'std'],
            app_dl_col: ['max', 'min', 'mean', 'median', 'std'],
            app_ul_col: ['max', 'min', 'mean', 'median', 'std'],
        }
        if rsrq_col and rsrq_col in df.columns:
            agg_dict[rsrq_col] = ['max', 'min', 'mean', 'median', 'std']

        df_stats = grouped.agg(agg_dict).reset_index()
        df_stats.columns = ['_'.join(col).strip('_') for col in df_stats.columns.values]
        
        # Calcula o valor mais frequente (moda) para o Rank/RI.
        if rank_col in df.columns:
            df_rank_mode = grouped[rank_col].apply(lambda x: x.mode().iloc[0] if not x.mode().empty else None).reset_index(name='Rank')
            df_stats = df_stats.merge(df_rank_mode, on=id_col, how='left')
        
        # Renomeia as colunas para nomes mais amigáveis.
        renomear = {
            f'{rsrp_col}_count': 'Amostra', f'{rsrp_col}_max': 'RSRP_max', f'{rsrp_col}_min': 'RSRP_min',
            f'{rsrp_col}_mean': 'RSRP_mean', f'{rsrp_col}_median': 'RSRP_median', f'{rsrp_col}_std': 'RSRP_std',
            f'{sinr_col}_max': 'SINR_max', f'{sinr_col}_min': 'SINR_min', f'{sinr_col}_mean': 'SINR_mean',
            f'{sinr_col}_median': 'SINR_median', f'{sinr_col}_std': 'SINR_std',
            f'{app_dl_col}_max': 'Throughput_DL_max', f'{app_dl_col}_min': 'Throughput_DL_min', f'{app_dl_col}_mean': 'Throughput_DL_mean',
            f'{app_dl_col}_median': 'Throughput_DL_median', f'{app_dl_col}_std': 'Throughput_DL_std',
            f'{app_ul_col}_max': 'Throughput_UL_max', f'{app_ul_col}_min': 'Throughput_UL_min', f'{app_ul_col}_mean': 'Throughput_UL_mean',
            f'{app_ul_col}_median': 'Throughput_UL_median', f'{app_ul_col}_std': 'Throughput_UL_std',
            id_col: id_col
        }
        if rsrq_col:
            renomear.update({
                f'{rsrq_col}_max': 'RSRQ_max', f'{rsrq_col}_min': 'RSRQ_min', f'{rsrq_col}_mean': 'RSRQ_mean',
                f'{rsrq_col}_median': 'RSRQ_median', f'{rsrq_col}_std': 'RSRQ_std',
            })
        df_stats = df_stats.rename(columns=renomear)

        # Converte throughput de bps para Mbps.
        cols_dl_ul = [f'Throughput_{dir}_{stat}' for dir in ['DL', 'UL'] for stat in ['max', 'min', 'mean', 'median', 'std']]
        for col in cols_dl_ul:
            if col in df_stats.columns:
                df_stats[col] = (df_stats[col] / 1000000).round(2)

        # Encontra a medição com o RSRP mais forte para cada ponto de análise.
        feedback.pushInfo("INFO: Identificando melhor servidor e vizinhança...")
        idx_max_rsrp = grouped[rsrp_col].idxmax().dropna().astype(int)
        df_max_rsrp = df.loc[idx_max_rsrp].copy()

        # Cria a lista de PCIs únicos e a contagem de PCIs para cada ponto.
        pci_list_str = grouped[pci_col].apply(lambda x: ",".join(map(str, sorted(set(map(int, x.dropna()))))))
        pci_unique_count = grouped[pci_col].nunique()
        df_max_rsrp['PCI_LISTA'] = df_max_rsrp[id_col].map(pci_list_str)
        df_max_rsrp['PCI_QTD'] = df_max_rsrp[id_col].map(pci_unique_count)

        # Conta a ocorrência de cada tipo de modulação.
        modulacoes_padrao = ['16QAM', '256QAM', '64QAM', 'QPSK']
        if tipo_rede == '4G':
            if modulation_col in df.columns:
                mod_counts = grouped[modulation_col].value_counts().unstack(fill_value=0).reindex(columns=modulacoes_padrao, fill_value=0)
                for mod in modulacoes_padrao:
                    df_max_rsrp[mod] = df_max_rsrp[id_col].map(mod_counts[mod])
        else: # 5G
            for col_mod, prefix in [(modulation_dl_col, 'DL'), (modulation_ul_col, 'UL')]:
                if col_mod in df.columns:
                    mod_counts = grouped[col_mod].value_counts().unstack(fill_value=0).reindex(columns=modulacoes_padrao, fill_value=0)
                    for mod in modulacoes_padrao:
                        df_max_rsrp[f'{mod}_{prefix}'] = df_max_rsrp[id_col].map(mod_counts[mod])
        
        df_max_rsrp = df_max_rsrp.rename(columns={pci_col: 'PCI_MAIOR_RSRP'})
        
        # Remove colunas intermediárias que não são necessárias no resultado final.
        colunas_para_remover = [rsrp_col, sinr_col, app_dl_col, app_ul_col, 'distance', 'fid', 'full_id', 'angle',rank_col]
        if tipo_rede == '4G':
            colunas_para_remover.append(modulation_col)
            if rsrq_col: colunas_para_remover.append(rsrq_col)
        else:
            colunas_para_remover.extend([modulation_dl_col, modulation_ul_col])
        df_max_rsrp = df_max_rsrp.drop(columns=colunas_para_remover, errors='ignore')
        
        # Junta o DataFrame com os dados do melhor servidor com o DataFrame de estatísticas.
        df_final = df_max_rsrp.merge(df_stats, on=id_col, how='left')
        
        # --- Etapa 9: Gerar Saídas ---
        feedback.pushInfo("INFO: Gerando arquivo CSV de saída...")
        df_final_csv = df_final.drop(columns=['geom'], errors='ignore')
        df_final_csv.to_csv(output_csv_path, index=False)
        results['Csv_otimizado'] = output_csv_path

        feedback.pushInfo("INFO: Criando camada de pontos otimizada...")
        # Define os campos da camada de saída com base nos tipos de dados do DataFrame.
        df_cols_sem_geom = [col for col in df_final.columns if col != 'geom']
        final_fields = QgsFields()
        for col_name in df_cols_sem_geom:
            dtype = df_final[col_name].dtype
            if pd.api.types.is_integer_dtype(dtype): variant_type = QVariant.Int
            elif pd.api.types.is_float_dtype(dtype): variant_type = QVariant.Double
            else: variant_type = QVariant.String
            final_fields.append(QgsField(col_name, variant_type))

        # Cria o "sink" (destino) para a nova camada de pontos.
        (sink, dest_id) = self.parameterAsSink(
            parameters, 'OUTPUT_LAYER', context,
            final_fields, QgsWkbTypes.Point, camada_vetorial.crs()
        )

        # Itera sobre o DataFrame final para criar cada feição na camada de saída.
        for _, row in df_final.iterrows():
            feat = QgsFeature(final_fields)
            if pd.notna(row['geom']):
                feat.setGeometry(QgsGeometry.fromWkt(str(row['geom'])))
            
            # Formata os atributos para serem compatíveis com a tabela de atributos do QGIS.
            attrs = []
            for col in df_cols_sem_geom:
                val = row[col]
                if isinstance(val, list):
                    val = ','.join(map(str, val))
                elif pd.isna(val):
                    val = None
                elif not isinstance(val, (int, float, str)):
                    val = str(val)
                attrs.append(val)
            feat.setAttributes(attrs)
            sink.addFeature(feat, QgsFeatureSink.FastInsert)
            
        
        # --- Etapa 10: Aplicar Simbologia ---
        feedback.pushInfo("INFO: Aplicando simbologia na camada de saída...")
        # ATENÇÃO: Os caminhos para os arquivos QML estão fixos. Para portabilidade,
        # armazene os arquivos de estilo junto com o script.
        qml_mapping = {
            'RSRP': r'G:\Drives compartilhados\Qgis\Arquivo de cores\Otimizar_DT_RSRP.qml',
            'RSRQ': r'G:\Drives compartilhados\Qgis\Arquivo de cores\Otimizar_DT_RSRQ.qml',
            'SINR': r'G:\Drives compartilhados\Qgis\Arquivo de cores\Otimizar_DT_SINR.qml',
            'Throughput DL': r'G:\Drives compartilhados\Qgis\Arquivo de cores\Otimizar_DT_Throughput_DL.qml',
            'Throughput UL': r'G:\Drives compartilhados\Qgis\Arquivo de cores\Otimizar_DT_Throughput_UL.qml'
        }
        qml_path = qml_mapping.get(tipo_simbologia)
                
        if qml_path and os.path.exists(qml_path):
            processing.run(
                'native:setlayerstyle',
                {
                    'INPUT': dest_id,
                    'STYLE': qml_path
                },
                context=context,
                is_child_algorithm=True
            )
            feedback.pushInfo(f"INFO: Simbologia '{tipo_simbologia}' aplicada com sucesso.")
        elif tipo_simbologia != 'Nenhuma':
            feedback.pushWarning(f"AVISO: Arquivo de estilo para '{tipo_simbologia}' não encontrado. A camada será carregada com estilo padrão.")
            
        feedback.pushInfo("SUCESSO: Processo concluído!")
        results['OUTPUT_LAYER'] = dest_id
        return results


    def name(self) -> str:
        return 'DT_UE_Measurement'

    def displayName(self) -> str:
        return 'DT_UE_Measurement'

    def group(self) -> str:
        return 'Drive test'
    def groupId(self):
        return 'Drive test'
        
    def icon(self):
        icon_path = r'G:\Drives compartilhados\Qgis\Arquivo de cores\icones\DT_UE.svg'

        if os.path.exists(icon_path):
            return QIcon(icon_path)
        else:
            return QIcon()

    def createInstance(self):
        return self.__class__()
        
    def shortHelpString(self) -> str:
        return """
        <div style="font-family: sans-serif; color: #333333;">
            <!-- Cabeçalho -->
            <h3 style="color: #2c3e50;">📶 Otimizador de Drive Test (4G/5G)</h3>
            <p>
            Esta ferramenta transforma dados brutos de drive test em uma camada de análise consolidada, com estatísticas detalhadas prontas para uso.
            </p>
            <hr>
            <!-- Funcionalidades -->
            <h4 style="color: #34495e;">Principais Funcionalidades</h4>
            <ul>
                <li><strong style="color: #2980b9;">🔍 Detecta</strong> automaticamente a tecnologia (4G/5G) a partir dos dados de entrada.</li>
                <li><strong style="color: #2980b9;">🔗️ Agrega</strong> medições de drive test em pontos de análise criados ao longo de uma camada de ruas.</li>
                <li><strong style="color: #2980b9;">📊 Calcula</strong> estatísticas completas (média, máximo, mínimo, desvio padrão) para KPIs como RSRP, SINR, RSRQ e Throughput.</li>
                <li><strong style="color: #2980b9;">📍 Identifica</strong> o PCI com sinal mais forte e analisa a presença de vizinhas em cada local.</li>
            </ul>

            <!-- Entradas -->
            <h4 style="color: #34495e;">Entradas Necessárias</h4>
            <p>
                A ferramenta requer uma <strong>Camada de Ruas</strong>, os <strong>Pontos de Drive Test</strong>, a <strong>Distância</strong> de análise e, opcionalmente, o <strong>parâmetro de simbologia</strong> para aplicar um estilo visual à camada de saída.
            </p>
            <!-- Resultados -->
            <h4 style="color: #34495e;">Saídas Geradas</h4>
            <p>
                Gera uma <strong>Camada de Pontos Otimizada</strong>, com estilo aplicado, para análise visual no QGIS e um <strong>Relatório CSV</strong> completo com todas as métricas calculadas.
            </p>
            <hr>
            <!-- Rodapé -->
            <p><i>Dados e Performance</i></p>

            </div>
        """

