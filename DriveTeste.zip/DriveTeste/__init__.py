def classFactory(iface):
    from .Drive_Teste_Menu import DriveTesteMenu
    return DriveTesteMenu(iface)